package application;

public class Card {
	String suit;
	String rank;
	int cardValue;
	public Card(String cardRank,String cardSuit,int cardPointValue){
		rank=cardRank;
		suit=cardSuit;
		cardValue=cardPointValue;
	}
	public Card(){
		
	}
	
	public String getSuit(){
		return suit;
	}
	 
	public String getRank(){
		return rank;
	}
	 
	public int getValue(){
		return cardValue;
	}
	 
	public int compareTo(Card otherCard){
		if(this.cardValue>otherCard.cardValue){
			return 1;
		}
		else if(this.cardValue<otherCard.cardValue){
			return -1;
		}
		else{
			return 0;
		}
	}
	 
	 public String toString(){
		 String name = ""+this.getRank()+" of "+this.getSuit();
		 return name;
	 }
}

	