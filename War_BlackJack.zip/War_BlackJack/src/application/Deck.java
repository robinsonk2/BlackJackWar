package application;

import java.util.ArrayList;
import java.util.List;

public class Deck {
	int size;
	List<Card> cards;
	Card onTop;
	public Deck() {
		cards = new ArrayList<Card>();
	}

	public Deck(String[] ranks, String[] suits, int[] values) {
		cards = new ArrayList<Card>();
		for (int s = 0; s < suits.length; s++) {
			for (int r = 0; r < ranks.length; r++) {
				Card card = new Card(ranks[r], suits[s], values[r]);
				cards.add(card);
				size = cards.size();

			}
		}
	}

	public Card deal() {
		if (size > 0) {
			size--;
			onTop=new Card();
			onTop = cards.get(size);
			cards.remove(size);
			return onTop;
		} else {
			return null;
		}

	}
	public void add(Card card){
		cards.add(card);
	}
	public Card get(int deckIndex){
		return cards.get(deckIndex);
	}
	public void remove(int deckIndex){
		cards.remove(deckIndex);
	}
	public int getSize() {
		return size;
	}

	public void shuffle() {
		Card temp;
		int random;
		for (int i = cards.size() - 1; i > 0; i--) {
			random = (int) (Math.random() * (i + 1));
			temp = cards.get(i);
			cards.set(i, cards.get(random));
			cards.set(random, temp);
		}
		size = cards.size();
	}
	
	public void printDeck(){
		for (int i = cards.size() - 1; i > 0; i--) {
			System.out.println(cards.get(i).toString());
		}
	}
}
