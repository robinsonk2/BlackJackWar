package application;

import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class BlackJackController {
	@FXML
	Button hit;
	@FXML
	Button stand;
	@FXML
	Button play;
	
	@FXML
	Label title_label;
	@FXML
	Label result;
	@FXML
	Label user;
	@FXML
	Label dealern;
	
	@FXML
	Label total_score;
	@FXML
	Label dealer_score;
	
	@FXML
	ImageView hand1;
	@FXML
	ImageView hand2;
	@FXML
	ImageView hand3;
	@FXML
	ImageView hand4;
	@FXML
	ImageView hand5;
	@FXML
	ImageView hand6;
	@FXML
	ImageView dealer1;
	@FXML
	ImageView dealer2;
	@FXML
	ImageView dealer3;
	@FXML
	ImageView dealer4;
	@FXML
	ImageView dealer5;
	@FXML
	ImageView dealer6;
	

	ImageView[] handImages;
	ImageView[] dealerImages;

	int userTotal;
	int dealerTotal;
	int handIndex;
	int dealerIndex;
	boolean isBusted;
	boolean dealerHasBlackJack;
	boolean userHasBlackJack;
	
	boolean checkedAce1;
	boolean checkedAce2;
	boolean checkedAce3;
	boolean checkedAce4;
	boolean checkedAce5;
	boolean checkedAce6;
	boolean checkedDealerAce1;
	boolean checkedDealerAce2;
	boolean checkedDealerAce3;
	boolean checkedDealerAce4;
	boolean checkedDealerAce5;
	boolean checkedDealerAce6;

	ArrayList<Card> hand;
	ArrayList<Card> dealer;
	Deck myBigDeck;
	Deck discards;

	public void play() {
		String[] ranks = { "ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "jack", "queen", "king" };
		String[] suits = { "clubs", "spades", "hearts", "diamonds", "clubs", "spades", "hearts", "diamonds", "clubs",
				"spades", "hearts", "diamonds", "clubs", "spades", "hearts", "diamonds", "clubs", "spades", "hearts",
				"diamonds", "clubs", "spades", "hearts", "diamonds", "clubs", "spades", "hearts", "diamonds", "clubs",
				"spades", "hearts", "diamonds", "clubs", "spades", "hearts", "diamonds" };
		int[] values = { 11, 2, 3, 4, 5, 6, 7, 8, 9, 10, 10, 10, 10 };

		hand = new ArrayList<Card>();
		dealer = new ArrayList<Card>();
		
		hand1.setImage(null);
		hand2.setImage(null);
		hand3.setImage(null);
		hand4.setImage(null);
		hand5.setImage(null);
		hand6.setImage(null);
		dealer1.setImage(null);
		dealer2.setImage(null);
		dealer3.setImage(null);
		dealer4.setImage(null);
		dealer5.setImage(null);
		dealer6.setImage(null);
		result.setText("");
		dealer_score.setText("");
		
		myBigDeck = new Deck(ranks, suits, values);
		for (int i = hand.size(); i > 0; i--) {
			hand.remove(i);
		}
		for (int j = dealer.size(); j > 0; j--) {
			dealer.remove(j);
		}
		myBigDeck.shuffle();
		
		handIndex = 0;
		dealerIndex = 0;
		userTotal = 0;
		dealerTotal = 0;
		
		dealerHasBlackJack = false;
		userHasBlackJack = false;
		isBusted = false;
		
		checkedAce1=false;
		checkedAce2=false;
		checkedAce3=false;
		checkedAce4=false;
		checkedAce5=false;
		checkedAce6=false;
		checkedDealerAce1=false;
		checkedDealerAce2=false;
		checkedDealerAce3=false;
		checkedDealerAce4=false;
		checkedDealerAce5=false;
		checkedDealerAce6=false;
		
		hit.setVisible(true);
		stand.setVisible(true);
		
		dealer.add(myBigDeck.deal());
		Image back = new Image("images/cards/back1.GIF");
		dealer1.setImage(back);
		dealerTotal += dealer.get(0).getValue();
		dealerIndex = 1;

		hand.add(myBigDeck.deal());
		hand1.setImage(getFileName(hand.get(0)));
		userTotal += hand.get(0).getValue();
		handIndex = 1;

		dealer.add(myBigDeck.deal());
		dealer2.setImage(getFileName(dealer.get(1)));
		dealerTotal += dealer.get(1).getValue();
		dealerIndex = 2;

		hand.add(myBigDeck.deal());
		hand2.setImage(getFileName(hand.get(1)));
		userTotal += hand.get(1).getValue();
		total_score.setText(Integer.toString(userTotal));
		handIndex = 2;
		
		if (userTotal == 21) {
			userHasBlackJack = true;
		}
		if (dealerTotal == 21) {
			dealer1.setImage(getFileName(dealer.get(0)));
			dealerHasBlackJack = true;
		}
		if(userHasBlackJack&&dealerHasBlackJack){
			push();
		}else if(userHasBlackJack){
			win();
		}
		else if(dealerHasBlackJack){
			lose();
		}
		

	}


	public void hit() {
		isBusted = false;
		hand.add(myBigDeck.deal());

		if (handIndex == 2) {
			hand3.setImage(getFileName(hand.get(2)));
			userTotal += hand.get(2).getValue();
			handIndex = 3;
		} else if (handIndex == 3) {
			hand4.setImage(getFileName(hand.get(3)));
			userTotal += hand.get(3).getValue();
			handIndex = 4;
		} else if (handIndex == 4) {
			hand5.setImage(getFileName(hand.get(4)));
			userTotal += hand.get(4).getValue();
			handIndex = 5;
		} else if (handIndex == 5) {
			hand6.setImage(getFileName(hand.get(5)));
			userTotal += hand.get(5).getValue();
			handIndex = 6;
		} else {
			System.out.println("NO");
		}

		total_score.setText(Integer.toString(userTotal));
		if (userTotal == 21) {
			dealer1.setImage(getFileName(dealer.get(0)));
			win();
		} 
		else if (userTotal > 21) {
			if (handIndex == 1) {
				if ((hand.get(0).getValue() == 11)&&(checkedAce1==false)) {
					userTotal -= 10;
					checkedAce1=true;
				} else {
					stand();
				}

			} else if (handIndex == 2) {
				if ((hand.get(0).getValue() == 11)&&(checkedAce1==false)) {
					userTotal -= 10;
					checkedAce1=true;
				} else if ((hand.get(1).getValue() == 11)&&(checkedAce2==false)) {
					userTotal -= 10;
					checkedAce2=true;
				} else {
					stand();
				}
			} else if (handIndex == 3) {
				if ((hand.get(0).getValue() == 11)&&(checkedAce1==false)) {
					userTotal -= 10;
					checkedAce1=true;
				} else if ((hand.get(1).getValue() == 11)&&(checkedAce2==false)) {
					userTotal -= 10;
					checkedAce2=true;
				} else if ((hand.get(2).getValue() == 11)&&(checkedAce3==false)) {
					userTotal -= 10;
					checkedAce3=true;
				} else {
					stand();
				}
			} else if (handIndex == 4) {
				if ((hand.get(0).getValue() == 11)&&(checkedAce1==false)) {
					userTotal -= 10;
					checkedAce1=true;
				} else if ((hand.get(1).getValue() == 11)&&(checkedAce2==false)) {
					userTotal -= 10;
					checkedAce2=true;
				} else if ((hand.get(2).getValue() == 11)&&(checkedAce3==false)) {
					userTotal -= 10;
					checkedAce3=true;
				} else if ((hand.get(3).getValue() == 11) &&(checkedAce4==false)){
					userTotal -= 10;
					checkedAce4=true;
				} else {
					stand();
				}
			} else if (handIndex == 5) {
				if ((hand.get(0).getValue() == 11)&&(checkedAce1==false)) {
					userTotal -= 10;
					checkedAce1=true;
				} else if ((hand.get(1).getValue() == 11)&&(checkedAce2==false)) {
					userTotal -= 10;
					checkedAce2=true;
				} else if ((hand.get(2).getValue() == 11)&&(checkedAce3==false)) {
					userTotal -= 10;
					checkedAce3=true;
				} else if ((hand.get(3).getValue() == 11) &&(checkedAce4==false)){
					userTotal -= 10;
					checkedAce4=true;
				} else if ((hand.get(4).getValue() == 11) &&(checkedAce4==false)){
					userTotal -= 10;
					checkedAce5=true;
				} else {
					stand();
				}
			} else if (handIndex == 6) {
				if ((hand.get(0).getValue() == 11)&&(checkedAce1==false)) {
					userTotal -= 10;
					checkedAce1=true;
				} else if ((hand.get(1).getValue() == 11)&&(checkedAce2==false)) {
					userTotal -= 10;
					checkedAce2=true;
				} else if ((hand.get(2).getValue() == 11)&&(checkedAce3==false)) {
					userTotal -= 10;
					checkedAce3=true;
				} else if ((hand.get(3).getValue() == 11) &&(checkedAce4==false)){
					userTotal -= 10;
					checkedAce4=true;
				} else if ((hand.get(4).getValue() == 11) &&(checkedAce4==false)){
					userTotal -= 10;
					checkedAce5=true;
				} 
				else if ((hand.get(5).getValue() == 11)&&(checkedAce5==false)) {
					userTotal -= 10;
					checkedAce5=true;
				} 
				else {
					stand();
				}
			
			}
			
			total_score.setText(Integer.toString(userTotal));
		}
			
	}
		

	

	public void stand() {
		hit.setVisible(false);
		stand.setVisible(false);
		total_score.setText(Integer.toString(userTotal));
		dealer1.setImage(getFileName(dealer.get(0)));
		if (userTotal > 21) {
			lose();
		} 
		else {
			
			while (dealerTotal < 17) {

				if (dealerIndex == 2) {
					dealer.add(myBigDeck.deal());
					dealer3.setImage(getFileName(dealer.get(2)));
					dealerTotal += dealer.get(2).getValue();
					dealerIndex = 3;
				} else if (dealerIndex == 3) {
					dealer.add(myBigDeck.deal());
					dealer4.setImage(getFileName(dealer.get(3)));
					dealerTotal += dealer.get(3).getValue();
					dealerIndex = 4;
				} else if (dealerIndex == 4) {
					dealer.add(myBigDeck.deal());
					dealer5.setImage(getFileName(dealer.get(4)));
					dealerTotal += dealer.get(4).getValue();
					dealerIndex = 5;
				} else if (dealerIndex == 5) {
					dealer.add(myBigDeck.deal());
					dealer6.setImage(getFileName(dealer.get(5)));
					dealerTotal += dealer.get(5).getValue();
					dealerIndex = 6;
				} else {
					System.out.println("NO");
				}
				
				if (dealerTotal > 21) {
					
					if (dealerIndex == 1) {
						if ((dealer.get(0).getValue() == 11)&&(checkedDealerAce1==false)) {
							dealerTotal -= 10;
							checkedDealerAce1=true;
						} else {
							win();
						}

					} else if (dealerIndex == 2) {
						if ((dealer.get(0).getValue() == 11)&&(checkedDealerAce1==false)) {
							dealerTotal -= 10;
							checkedDealerAce1=true;
						} else if ((dealer.get(1).getValue() == 11)&&(checkedDealerAce2==false)) {
							dealerTotal -= 10;
							checkedDealerAce2=true;
						} else {
							win();
						}
					} else if (dealerIndex == 3) {
						if ((dealer.get(0).getValue() == 11)&&(checkedDealerAce1==false)) {
							dealerTotal -= 10;
							checkedDealerAce1=true;
						} else if ((dealer.get(1).getValue() == 11)&&(checkedDealerAce2==false)) {
							dealerTotal -= 10;
							checkedDealerAce2=true;
						} else if ((dealer.get(2).getValue() == 11)&&(checkedDealerAce3==false)) {
							dealerTotal -= 10;
							checkedDealerAce3=true;
						} else {
							win();
						}
					} else if (dealerIndex == 4) {
						if ((dealer.get(0).getValue() == 11)&&(checkedDealerAce1==false)) {
							dealerTotal -= 10;
							checkedDealerAce1=true;
						} else if ((dealer.get(1).getValue() == 11)&&(checkedDealerAce2==false)) {
							dealerTotal -= 10;
							checkedDealerAce2=true;
						} else if ((dealer.get(2).getValue() == 11)&&(checkedDealerAce3==false)) {
							dealerTotal -= 10;
							checkedDealerAce3=true;
						} else if ((dealer.get(3).getValue() == 11) &&(checkedDealerAce4==false)){
							dealerTotal -= 10;
							checkedDealerAce4=true;
						} else {
							win();
						}
					} else if (dealerIndex == 5) {
						if ((dealer.get(0).getValue() == 11)&&(checkedDealerAce1==false)) {
							dealerTotal -= 10;
							checkedDealerAce1=true;
						} else if ((dealer.get(1).getValue() == 11)&&(checkedDealerAce2==false)) {
							dealerTotal -= 10;
							checkedDealerAce2=true;
						} else if ((dealer.get(2).getValue() == 11)&&(checkedDealerAce3==false)) {
							dealerTotal -= 10;
							checkedDealerAce3=true;
						} else if ((dealer.get(3).getValue() == 11) &&(checkedDealerAce4==false)){
							dealerTotal -= 10;
							checkedDealerAce4=true;
						} else if ((dealer.get(4).getValue() == 11) &&(checkedDealerAce4==false)){
							dealerTotal -= 10;
							checkedDealerAce5=true;
						} else {
							win();
						}
					} else if (dealerIndex == 6) {
						if ((dealer.get(0).getValue() == 11)&&(checkedDealerAce1==false)) {
							dealerTotal -= 10;
							checkedDealerAce1=true;
						} else if ((dealer.get(1).getValue() == 11)&&(checkedDealerAce2==false)) {
							dealerTotal -= 10;
							checkedDealerAce2=true;
						} else if ((dealer.get(2).getValue() == 11)&&(checkedDealerAce3==false)) {
							dealerTotal -= 10;
							checkedDealerAce3=true;
						} else if ((dealer.get(3).getValue() == 11) &&(checkedDealerAce4==false)){
							dealerTotal -= 10;
							checkedDealerAce4=true;
						} else if ((dealer.get(4).getValue() == 11) &&(checkedDealerAce4==false)){
							dealerTotal -= 10;
							checkedDealerAce5=true;
						} else if ((dealer.get(5).getValue() == 11)&&(checkedDealerAce5==false)) {
							dealerTotal -= 10;
							checkedDealerAce5=true;
						} else {
							win();
						}
					}
				
				}//closes if(dealerTotal>21) loop 
			}//closes while(dealerTotal<17) loop
			if ((dealerTotal < 21) && (userTotal > dealerTotal)) {
				win();
			} else if ((dealerTotal < 21) && (userTotal < dealerTotal)) {
				lose();
			}else if ((dealerTotal == userTotal)) {
				push();
			}else if(dealerTotal==21){
				lose();
			}
		}//closes else loop
	} //closes stand method


	public void win() {
		if(userHasBlackJack){
			result.setText("BLACKJACK! YOU WIN");
		}
		else if(!userHasBlackJack){
			result.setText("YOU WIN");
		}
		dealer_score.setText("Total: "+Integer.toString(dealerTotal));
		hit.setVisible(false);
		stand.setVisible(false);
	}

	public void lose() {
		if(dealerHasBlackJack){
			result.setText("Dealer has BlackJack :( YOU LOSE");
		}
		else if(!userHasBlackJack){
			result.setText("YOU LOSE");
		}
		dealer_score.setText("Total: "+Integer.toString(dealerTotal));
		hit.setVisible(false);
		stand.setVisible(false);
	}

	public void push() {
		result.setText("PUSH");
		dealer_score.setText("Total: "+Integer.toString(dealerTotal));
		hit.setVisible(false);
		stand.setVisible(false);
	}

	public Image getFileName(Card c) {
		String fileName = "/images/cards/";
		if (c == null) {
			return new Image("images/cards/back1.GIF");
		}
		fileName += "" + c.getRank() + c.getSuit();
		fileName += ".GIF";
		return new Image(fileName);
	}
	
}//closes class
