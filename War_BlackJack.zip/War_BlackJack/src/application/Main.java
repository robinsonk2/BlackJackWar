package application;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class Main extends Application {

	@Override
	public void start(Stage primaryStage) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("/application/GameGUI.fxml"));
			Parent blackJackRoot = FXMLLoader.load(getClass().getResource("/application/BlackJackGameGUI.fxml"));
			Parent warRoot = FXMLLoader.load(getClass().getResource("/application/WarGameGUI.fxml"));
			Scene bjScene = new Scene(blackJackRoot);
			Scene warScene = new Scene(warRoot);

			Button b = (Button) root.lookup("#blackjack");

			Button w = (Button) root.lookup("#war");

			b.setOnAction(e -> {
				primaryStage.setScene(bjScene);
			});

			w.setOnAction(e -> {
				primaryStage.setScene(warScene);
			});

			Scene scene = new Scene(root);
			scene.getStylesheets().add(this.getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		launch(args);
	}

}
