package application;

import java.util.ArrayList;

import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class WarController {
	@FXML
	ImageView playerDeckImage;
	@FXML
	ImageView playerDeckWonImage;
	@FXML
	ImageView computerDeckImage;
	@FXML
	ImageView computerDeckWonImage;
	@FXML
	ImageView currentPlayerImage;
	@FXML
	ImageView player1Image;
	@FXML
	ImageView player2Image;
	@FXML
	ImageView player3Image;
	@FXML
	ImageView currentCPUImage;
	@FXML
	ImageView cpu1Image;
	@FXML
	ImageView cpu2Image;
	@FXML
	ImageView cpu3Image;

	@FXML
	Label playerCards;
	@FXML
	Label playerCardsWon;
	@FXML
	Label num_cardsPlayerWon;
	@FXML
	Label num_cardsPlayerDeck;
	@FXML
	Label computerCards;
	@FXML
	Label computerCardsWon;
	@FXML
	Label num_cardsCPUWon;
	@FXML
	Label num_cardsCPUDeck;
	@FXML
	Label result;

	@FXML
	Button play;
	@FXML
	Button draw;
	@FXML
	Button goToWar;
	@FXML
	Button addToWinner;

	Deck myDeck;

	ArrayList<Card> playerDeck;
	ArrayList<Card> computerDeck;
	ArrayList<Card> playerWon;
	ArrayList<Card> computerWon;
	ArrayList<Card> toWinFromWar;
	int winner;

	Card player1;
	Card player2;
	Card player3;
	Card cpu1;
	Card cpu2;
	Card cpu3;
	Card currentPlayer;
	Card currentCPU;

	boolean justStarted;

	public void playWar() {

		String[] ranks = { "ace", "2", "3", "4", "5", "6", "7", "8", "9", "10", "jack", "queen", "king" };
		String[] suits = { "clubs", "spades", "hearts", "diamonds" };
		int[] values = { 14, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13 };
		myDeck = new Deck(ranks, suits, values);
		result.setText(" ");
		playerDeck = new ArrayList<Card>();
		computerDeck = new ArrayList<Card>();
		playerWon = new ArrayList<Card>();
		computerWon = new ArrayList<Card>();
		toWinFromWar = new ArrayList<Card>();
		winner = 0;

		currentPlayer = new Card();
		currentCPU = new Card();

		num_cardsPlayerWon.setText("" + 0);
		num_cardsCPUWon.setText("" + 0);

		play.setVisible(false);
		draw.setVisible(true);
		result.setVisible(false);
		justStarted = true;
		myDeck.shuffle();
		currentPlayerImage.setImage(null);
		currentCPUImage.setImage(null);
		
		while (myDeck.getSize() > 0) {
			playerDeck.add(myDeck.deal());
			computerDeck.add(myDeck.deal());
		}
		num_cardsPlayerDeck.setText(Integer.toString(playerDeck.size()));
		num_cardsCPUDeck.setText(Integer.toString(computerDeck.size()));
	}

	public void draw() {

		checkDecks();
		draw.setVisible(false);

		currentPlayer = playerDeck.get(playerDeck.size() - 1);
		playerDeck.remove(playerDeck.size() - 1);
		currentCPU = computerDeck.get(computerDeck.size() - 1);
		computerDeck.remove(computerDeck.size() - 1);
		toWinFromWar.add(currentPlayer);
		toWinFromWar.add(currentCPU);
		currentPlayerImage.setImage(getFileName(currentPlayer));
		currentCPUImage.setImage(getFileName(currentCPU));
		result.setVisible(true);
		if (currentPlayer.cardValue > currentCPU.cardValue) {
			result.setText("You win the draw!");
			addToWinner.setVisible(true);
		} else if (currentPlayer.cardValue < currentCPU.cardValue) {
			result.setText("Computer wins the draw.");
			addToWinner.setVisible(true);
		} else {
			result.setText("WAR!");
			goToWar.setVisible(true);
			addToWinner.setVisible(false);
		}

	}

	public void addToWinner() {

		if (currentPlayer.getValue() > currentCPU.getValue()) {
			winner = 1;
		} else if (currentPlayer.cardValue < currentCPU.cardValue) {
			winner = 2;
		}

		if (winner == 1) {
			while (toWinFromWar.size()>0) {
				playerWon.add(toWinFromWar.get(toWinFromWar.size()-1));
				toWinFromWar.remove(toWinFromWar.size()-1);
				playerDeckWonImage.setVisible(true);
			}
		
		}
		if (winner == 2) {
			while(toWinFromWar.size()>0){
				computerWon.add(toWinFromWar.get(toWinFromWar.size()-1));
				toWinFromWar.remove(toWinFromWar.size()-1);
				computerDeckWonImage.setVisible(true);
			}
			
		}
		
		result.setVisible(false);
		
		currentPlayerImage.setImage(null);
		currentCPUImage.setImage(null);
		currentPlayerImage.setImage(null);
		currentCPUImage.setImage(null);
		
		player1Image.setImage(null);
		player2Image.setImage(null);
		player3Image.setImage(null);
		cpu1Image.setImage(null);
		cpu2Image.setImage(null);
		cpu3Image.setImage(null);
		
		player1Image.setVisible(false);
		player2Image.setVisible(false);
		player3Image.setVisible(false);
		cpu1Image.setVisible(false);
		cpu2Image.setVisible(false);
		cpu3Image.setVisible(false);
		draw.setVisible(true);
		goToWar.setVisible(false);
		addToWinner.setVisible(false);
		checkDecks();
		num_cardsPlayerDeck.setText(Integer.toString(playerDeck.size()));
		num_cardsCPUDeck.setText(Integer.toString(computerDeck.size()));
		num_cardsPlayerWon.setText(Integer.toString(playerWon.size()));
		num_cardsCPUWon.setText(Integer.toString(computerWon.size()));
	}

	public void war() {
		goToWar.setVisible(false);
		player1Image.setVisible(true);
		player2Image.setVisible(true);
		player3Image.setVisible(true);
		cpu1Image.setVisible(true);
		cpu2Image.setVisible(true);
		cpu3Image.setVisible(true);

		checkDecks();
		num_cardsPlayerDeck.setText(Integer.toString(playerDeck.size()));
		num_cardsCPUDeck.setText(Integer.toString(computerDeck.size()));
		num_cardsPlayerWon.setText(Integer.toString(playerWon.size()));
		num_cardsCPUWon.setText(Integer.toString(computerWon.size()));
		
		player1 = playerDeck.get(playerDeck.size() - 1);
		playerDeck.remove(playerDeck.size() - 1);
		player1Image.setImage(getFileName(player1));
		cpu1 = computerDeck.get(computerDeck.size() - 1);
		computerDeck.remove(computerDeck.size() - 1);
		cpu1Image.setImage(getFileName(cpu1));
		
		checkDecks();
		num_cardsPlayerDeck.setText(Integer.toString(playerDeck.size()));
		num_cardsCPUDeck.setText(Integer.toString(computerDeck.size()));
		num_cardsPlayerWon.setText(Integer.toString(playerWon.size()));
		num_cardsCPUWon.setText(Integer.toString(computerWon.size()));
		
		player2 = playerDeck.get(playerDeck.size() - 1);
		playerDeck.remove(playerDeck.size() - 1);
		player2Image.setImage(getFileName(player2));
		cpu2 = computerDeck.get(computerDeck.size() - 1);
		computerDeck.remove(computerDeck.size() - 1);
		cpu2Image.setImage(getFileName(cpu2));
		
		checkDecks();
		num_cardsPlayerDeck.setText(Integer.toString(playerDeck.size()));
		num_cardsCPUDeck.setText(Integer.toString(computerDeck.size()));
		num_cardsPlayerWon.setText(Integer.toString(playerWon.size()));
		num_cardsCPUWon.setText(Integer.toString(computerWon.size()));
		
		player3 = playerDeck.get(playerDeck.size() - 1);
		playerDeck.remove(playerDeck.size() - 1);
		player3Image.setImage(getFileName(player3));
		cpu3 = computerDeck.get(computerDeck.size() - 1);
		computerDeck.remove(computerDeck.size() - 1);
		cpu3Image.setImage(getFileName(cpu3));
		
		checkDecks();
		num_cardsPlayerDeck.setText(Integer.toString(playerDeck.size()));
		num_cardsCPUDeck.setText(Integer.toString(computerDeck.size()));
		num_cardsPlayerWon.setText(Integer.toString(playerWon.size()));
		num_cardsCPUWon.setText(Integer.toString(computerWon.size()));
		
		toWinFromWar.add(player1);
		toWinFromWar.add(player2);
		toWinFromWar.add(player3);
		toWinFromWar.add(cpu1);
		toWinFromWar.add(cpu2);
		toWinFromWar.add(cpu3);

		draw();
	}

	public void checkDecks() {
		if (playerDeck.size() == 0) {
			if (playerWon.size() == 0) {
				lose();
			} else {
				shuffle(playerWon);
				while(playerWon.size() >0) {
					playerDeck.add(playerWon.get(playerWon.size()-1));
					playerWon.remove(playerWon.size()-1);
				}
				playerDeckWonImage.setVisible(false);
			}
		}
		if (computerDeck.size() == 0) {
			if (computerWon.size() == 0) {
				win();
			} else {
				shuffle(computerWon);

				while(computerWon.size()>0) {
					computerDeck.add(computerWon.get(computerWon.size()-1));
					computerWon.remove(computerWon.size()-1);
				}
				computerDeckWonImage.setVisible(false);
			}
		}
	}

	public void shuffle(ArrayList<Card> deckToShuffle) {
		Card temp;
		int random;
		for (int i = deckToShuffle.size() - 1; i > 0; i--) {
			random = (int) (Math.random() * (i + 1));
			temp = deckToShuffle.get(i);
			deckToShuffle.set(i, deckToShuffle.get(random));
			deckToShuffle.set(random, temp);
		}
	}

	public void win() {
		num_cardsPlayerDeck.setText(Integer.toString(playerDeck.size()));
		num_cardsCPUDeck.setText(Integer.toString(computerDeck.size()));
		num_cardsPlayerWon.setText(Integer.toString(playerWon.size()));
		num_cardsCPUWon.setText(Integer.toString(computerWon.size()));
		
		computerDeckWonImage.setVisible(false);
		computerDeckImage.setVisible(false);
		result.setVisible(true);
		result.setText("YOU WIN THE GAME OF WAR");
		play.setVisible(true);
		addToWinner.setVisible(false);
		goToWar.setVisible(false);
		draw.setVisible(false);
	}

	public void lose() {
		num_cardsPlayerDeck.setText(Integer.toString(playerDeck.size()));
		num_cardsCPUDeck.setText(Integer.toString(computerDeck.size()));
		num_cardsPlayerWon.setText(Integer.toString(playerWon.size()));
		num_cardsCPUWon.setText(Integer.toString(computerWon.size()));
		
		playerDeckWonImage.setVisible(false);
		playerDeckImage.setVisible(false);
		result.setVisible(true);
		result.setText("YOU HAVE LOST THE GAME OF WAR");
		play.setVisible(true);
		addToWinner.setVisible(false);
		goToWar.setVisible(false);
		draw.setVisible(false);
	}

	public Image getFileName(Card c) {
		String fileName = "/images/cards/";
		if (c == null) {
			return new Image("images/cards/back1.GIF");
		}
		fileName += "" + c.getRank() + c.getSuit();
		fileName += ".GIF";
		return new Image(fileName);
	}
}
